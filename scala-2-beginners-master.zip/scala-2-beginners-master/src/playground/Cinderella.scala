package playground


class Cinderella {

}
